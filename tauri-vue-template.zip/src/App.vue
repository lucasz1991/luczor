<script setup lang="ts">
  import GreetComponent from './components/GreetComponent.vue'
  const store = useStore()
  store.initApp()
</script>

<template>
  <main class="flex-1 flex flex-col items-center justify-center min-h-screen">
    <h1>Welcome to Luczor </h1>


    <GreetComponent />
  </main>
</template>
